const { google } = require('googleapis');

function getOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    `${process.env.BASE_URL}/auth/google/callback`
  );
}

function getAuthUrl() {
  const client = getOAuthClient();
  return client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: [
      'openid',
      'email',
      'profile',
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/gmail.readonly',
    ],
  });
}

function getClientForUser(user) {
  const client = getOAuthClient();
  client.setCredentials({
    access_token:  user.access_token,
    refresh_token: user.refresh_token,
  });
  // Auto-refresh token quando expirar
  client.on('tokens', (tokens) => {
    const { stmts } = require('./db');
    stmts.updateTokens.run(tokens.access_token, tokens.refresh_token || null, user.id);
  });
  return client;
}

module.exports = { getOAuthClient, getAuthUrl, getClientForUser };
