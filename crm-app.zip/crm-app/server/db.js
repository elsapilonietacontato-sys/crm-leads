const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'crm.db');

// Garante que o diretório existe
const fs = require('fs');
const dir = path.dirname(DB_PATH);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(DB_PATH);

// ── Habilita WAL para melhor performance ──────────────────────────────────────
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── Criação das tabelas ───────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    google_id    TEXT    UNIQUE NOT NULL,
    email        TEXT    NOT NULL,
    name         TEXT,
    picture      TEXT,
    access_token TEXT,
    refresh_token TEXT,
    created_at   TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS leads (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        TEXT    NOT NULL,
    company     TEXT,
    channel     TEXT    DEFAULT 'WhatsApp',
    contact     TEXT,
    tag         TEXT    DEFAULT 'MTS',
    status      TEXT    DEFAULT 'novo',
    next_fu     TEXT,
    fu_count    INTEGER DEFAULT 0,
    notes       TEXT,
    created_at  TEXT    DEFAULT (datetime('now')),
    updated_at  TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS activities (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lead_id     INTEGER REFERENCES leads(id) ON DELETE SET NULL,
    description TEXT    NOT NULL,
    contact     TEXT,
    origin      TEXT    DEFAULT 'Manual',
    due_date    TEXT,
    done        INTEGER DEFAULT 0,
    gcal_event_id TEXT,
    created_at  TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS followup_messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lead_id     INTEGER REFERENCES leads(id) ON DELETE CASCADE,
    message     TEXT    NOT NULL,
    channel     TEXT,
    sent_at     TEXT    DEFAULT (datetime('now'))
  );
`);

// ── Helpers ───────────────────────────────────────────────────────────────────
const stmts = {
  // Users
  upsertUser: db.prepare(`
    INSERT INTO users (google_id, email, name, picture, access_token, refresh_token)
    VALUES (@google_id, @email, @name, @picture, @access_token, @refresh_token)
    ON CONFLICT(google_id) DO UPDATE SET
      email=excluded.email, name=excluded.name, picture=excluded.picture,
      access_token=excluded.access_token,
      refresh_token=COALESCE(excluded.refresh_token, users.refresh_token)
  `),
  getUserByGoogleId: db.prepare(`SELECT * FROM users WHERE google_id = ?`),
  getUserById:       db.prepare(`SELECT * FROM users WHERE id = ?`),
  updateTokens:      db.prepare(`UPDATE users SET access_token=?, refresh_token=COALESCE(?,refresh_token) WHERE id=?`),

  // Leads
  getLeads:    db.prepare(`SELECT * FROM leads WHERE user_id=? ORDER BY created_at DESC`),
  getLead:     db.prepare(`SELECT * FROM leads WHERE id=? AND user_id=?`),
  insertLead:  db.prepare(`INSERT INTO leads (user_id,name,company,channel,contact,tag,status,next_fu,notes) VALUES (@user_id,@name,@company,@channel,@contact,@tag,@status,@next_fu,@notes)`),
  updateLead:  db.prepare(`UPDATE leads SET name=@name,company=@company,channel=@channel,contact=@contact,tag=@tag,status=@status,next_fu=@next_fu,fu_count=@fu_count,notes=@notes,updated_at=datetime('now') WHERE id=@id AND user_id=@user_id`),
  deleteLead:  db.prepare(`DELETE FROM leads WHERE id=? AND user_id=?`),

  // Activities
  getActivities:   db.prepare(`SELECT * FROM activities WHERE user_id=? ORDER BY due_date ASC, created_at DESC`),
  insertActivity:  db.prepare(`INSERT INTO activities (user_id,lead_id,description,contact,origin,due_date,gcal_event_id) VALUES (@user_id,@lead_id,@description,@contact,@origin,@due_date,@gcal_event_id)`),
  updateActivity:  db.prepare(`UPDATE activities SET description=@description,contact=@contact,origin=@origin,due_date=@due_date,done=@done WHERE id=@id AND user_id=@user_id`),
  doneActivity:    db.prepare(`UPDATE activities SET done=@done WHERE id=@id AND user_id=@user_id`),
  deleteActivity:  db.prepare(`DELETE FROM activities WHERE id=? AND user_id=?`),
};

module.exports = { db, stmts };
