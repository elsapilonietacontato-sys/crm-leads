const express  = require('express');
const router   = express.Router();
const { stmts } = require('./db');
const { getAuthUrl, getOAuthClient } = require('./auth');
const { listUpcomingEvents, createEvent, createReminder, deleteEvent, getRecentEmails, daysAhead, today } = require('./google');
const { google } = require('googleapis');

// ── Middleware: exige login ───────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (!req.session?.userId) return res.status(401).json({ error: 'Não autenticado' });
  const user = stmts.getUserById.get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Usuário não encontrado' });
  req.user = user;
  next();
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
router.get('/auth/google', (req, res) => {
  res.redirect(getAuthUrl());
});

router.get('/auth/google/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=sem_codigo');
  try {
    const client    = getOAuthClient();
    const { tokens } = await client.getToken(code);
    client.setCredentials(tokens);

    const oauth2 = google.oauth2({ version: 'v2', auth: client });
    const { data: profile } = await oauth2.userinfo.get();

    stmts.upsertUser.run({
      google_id:     profile.id,
      email:         profile.email,
      name:          profile.name,
      picture:       profile.picture,
      access_token:  tokens.access_token,
      refresh_token: tokens.refresh_token || null,
    });

    const user = stmts.getUserByGoogleId.get(profile.id);
    req.session.userId = user.id;
    res.redirect('/');
  } catch (err) {
    console.error('OAuth error:', err.message);
    res.redirect('/?error=oauth_falhou');
  }
});

router.get('/auth/me', requireAuth, (req, res) => {
  const { id, email, name, picture } = req.user;
  res.json({ id, email, name, picture });
});

router.post('/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// ── LEADS ─────────────────────────────────────────────────────────────────────
router.get('/leads', requireAuth, (req, res) => {
  res.json(stmts.getLeads.all(req.user.id));
});

router.post('/leads', requireAuth, (req, res) => {
  const { name, company, channel, contact, tag, status, notes } = req.body;
  if (!name) return res.status(400).json({ error: 'Nome obrigatório' });
  const d1 = 2; // padrão
  const next_fu = status === 'novo' ? daysAhead(d1) : null;
  const info = stmts.insertLead.run({ user_id: req.user.id, name, company: company||'', channel: channel||'WhatsApp', contact: contact||'', tag: tag||'MTS', status: status||'novo', next_fu, notes: notes||'' });
  res.json(stmts.getLead.get(info.lastInsertRowid, req.user.id));
});

router.put('/leads/:id', requireAuth, (req, res) => {
  const { name, company, channel, contact, tag, status, next_fu, fu_count, notes } = req.body;
  stmts.updateLead.run({ id: req.params.id, user_id: req.user.id, name, company: company||'', channel: channel||'WhatsApp', contact: contact||'', tag: tag||'MTS', status: status||'novo', next_fu: next_fu||null, fu_count: fu_count||0, notes: notes||'' });
  res.json(stmts.getLead.get(req.params.id, req.user.id));
});

router.delete('/leads/:id', requireAuth, (req, res) => {
  stmts.deleteLead.run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// Avança ciclo de follow-up
router.post('/leads/:id/followup-done', requireAuth, (req, res) => {
  const lead = stmts.getLead.get(req.params.id, req.user.id);
  if (!lead) return res.status(404).json({ error: 'Lead não encontrado' });
  const days = [2, 7, 14];
  const newCount = (lead.fu_count || 0) + 1;
  let newStatus = lead.status;
  let next_fu   = null;
  if (newCount < 3) {
    next_fu = daysAhead(days[newCount]);
    newStatus = 'follow-up';
  } else {
    newStatus = 'descartado';
  }
  stmts.updateLead.run({ ...lead, fu_count: newCount, next_fu, status: newStatus });
  res.json(stmts.getLead.get(req.params.id, req.user.id));
});

// ── ACTIVITIES ────────────────────────────────────────────────────────────────
router.get('/activities', requireAuth, (req, res) => {
  res.json(stmts.getActivities.all(req.user.id));
});

router.post('/activities', requireAuth, async (req, res) => {
  const { description, contact, origin, due_date, lead_id, create_reminder } = req.body;
  if (!description) return res.status(400).json({ error: 'Descrição obrigatória' });
  let gcal_event_id = null;
  if (create_reminder && due_date) {
    try {
      const ev = await createReminder(req.user, { summary: description, description: `Contato: ${contact||''}`, dateStr: due_date });
      gcal_event_id = ev.id;
    } catch (e) { console.warn('Reminder creation failed:', e.message); }
  }
  const info = stmts.insertActivity.run({ user_id: req.user.id, lead_id: lead_id||null, description, contact: contact||'', origin: origin||'Manual', due_date: due_date||today(), gcal_event_id });
  res.json({ id: info.lastInsertRowid, description, contact, origin, due_date, done: 0, gcal_event_id });
});

router.put('/activities/:id', requireAuth, (req, res) => {
  const { description, contact, origin, due_date, done } = req.body;
  stmts.updateActivity.run({ id: req.params.id, user_id: req.user.id, description, contact: contact||'', origin: origin||'Manual', due_date: due_date||today(), done: done?1:0 });
  res.json({ ok: true });
});

router.patch('/activities/:id/done', requireAuth, (req, res) => {
  const { done } = req.body;
  stmts.doneActivity.run({ id: req.params.id, user_id: req.user.id, done: done?1:0 });
  res.json({ ok: true });
});

router.delete('/activities/:id', requireAuth, async (req, res) => {
  const act = stmts.getActivities.all(req.user.id).find(a => a.id == req.params.id);
  if (act?.gcal_event_id) {
    try { await deleteEvent(req.user, act.gcal_event_id); } catch(e){}
  }
  stmts.deleteActivity.run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// ── GOOGLE CALENDAR ───────────────────────────────────────────────────────────
router.get('/calendar/events', requireAuth, async (req, res) => {
  try {
    const events = await listUpcomingEvents(req.user, 30);
    res.json(events);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/calendar/events', requireAuth, async (req, res) => {
  try {
    const ev = await createEvent(req.user, req.body);
    // Marca lead como agendado se houver nome
    if (req.body.leadId) {
      const lead = stmts.getLead.get(req.body.leadId, req.user.id);
      if (lead) stmts.updateLead.run({ ...lead, status: 'agendado', next_fu: null });
    }
    res.json(ev);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GMAIL: escanear emails por ações pendentes ────────────────────────────────
router.get('/gmail/scan', requireAuth, async (req, res) => {
  try {
    const emails = await getRecentEmails(req.user, 20);
    const withActions = emails.filter(e => e.pendingAction);
    res.json({ total: emails.length, withActions, all: emails });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── DASHBOARD STATS ───────────────────────────────────────────────────────────
router.get('/dashboard', requireAuth, (req, res) => {
  const leads = stmts.getLeads.all(req.user.id);
  const acts  = stmts.getActivities.all(req.user.id);
  const tod   = today();

  const active    = leads.filter(l => l.status !== 'descartado');
  const meetings  = leads.filter(l => l.status === 'agendado').length;
  const overdue   = leads.filter(l => l.next_fu && l.next_fu < tod && l.status !== 'agendado' && l.status !== 'descartado').length;
  const todayFU   = leads.filter(l => l.next_fu === tod && l.status !== 'agendado' && l.status !== 'descartado').length;
  const actOverdue = acts.filter(a => !a.done && a.due_date < tod).length;

  res.json({ totalLeads: active.length, meetings, overdue, todayFU, actOverdue, leads, activities: acts });
});

module.exports = router;
