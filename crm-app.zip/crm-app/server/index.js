require('dotenv').config();
const express        = require('express');
const session        = require('express-session');
const SQLiteStore    = require('connect-sqlite3')(session);
const path           = require('path');
const fs             = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Garante diretórios ────────────────────────────────────────────────────────
['data'].forEach(d => { const p = path.join(__dirname, '..', d); if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); });

// ── Middlewares ───────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: path.join(__dirname, '..', 'data') }),
  secret: process.env.SESSION_SECRET || 'dev-secret-troque-em-producao',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 dias
  },
}));

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api', require('./routes'));

// ── SPA fallback ─────────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 CRM Leads rodando em http://localhost:${PORT}`);
  console.log(`   Google OAuth callback: ${process.env.BASE_URL || 'http://localhost:'+PORT}/auth/google/callback\n`);
});
