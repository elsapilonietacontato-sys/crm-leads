const { google } = require('googleapis');
const { getClientForUser } = require('./auth');

// ── Helpers de data ───────────────────────────────────────────────────────────
function today() {
  return new Date().toISOString().slice(0, 10);
}
function daysAhead(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

// ── CALENDAR ─────────────────────────────────────────────────────────────────
async function listUpcomingEvents(user, days = 30) {
  const auth   = getClientForUser(user);
  const cal    = google.calendar({ version: 'v3', auth });
  const start  = new Date().toISOString();
  const end    = new Date(Date.now() + days * 86400000).toISOString();

  const res = await cal.events.list({
    calendarId: 'primary',
    timeMin: start,
    timeMax: end,
    maxResults: 50,
    singleEvents: true,
    orderBy: 'startTime',
    timeZone: 'America/Bogota',
  });
  return res.data.items || [];
}

async function createEvent(user, { summary, description, startDateTime, endDateTime, attendeeEmail, addMeet }) {
  const auth = getClientForUser(user);
  const cal  = google.calendar({ version: 'v3', auth });

  const event = {
    summary,
    description,
    start: { dateTime: startDateTime, timeZone: 'America/Bogota' },
    end:   { dateTime: endDateTime,   timeZone: 'America/Bogota' },
    attendees: attendeeEmail ? [{ email: attendeeEmail }] : [],
    reminders: { useDefault: false, overrides: [{ method: 'popup', minutes: 30 }, { method: 'email', minutes: 60 }] },
  };
  if (addMeet) event.conferenceData = { createRequest: { requestId: `crm-${Date.now()}`, conferenceSolutionKey: { type: 'hangoutsMeet' } } };

  const res = await cal.events.insert({
    calendarId: 'primary',
    resource: event,
    conferenceDataVersion: addMeet ? 1 : 0,
    sendUpdates: attendeeEmail ? 'all' : 'none',
  });
  return res.data;
}

async function createReminder(user, { summary, description, dateStr }) {
  const auth = getClientForUser(user);
  const cal  = google.calendar({ version: 'v3', auth });

  const start = new Date(`${dateStr}T09:00:00-05:00`).toISOString();
  const end   = new Date(`${dateStr}T09:30:00-05:00`).toISOString();

  const res = await cal.events.insert({
    calendarId: 'primary',
    resource: {
      summary: `🔔 CRM: ${summary}`,
      description,
      start: { dateTime: start, timeZone: 'America/Bogota' },
      end:   { dateTime: end,   timeZone: 'America/Bogota' },
      reminders: { useDefault: false, overrides: [{ method: 'popup', minutes: 60 }, { method: 'email', minutes: 60 }] },
      colorId: '6', // Tangerine — destaque visual
    },
  });
  return res.data;
}

async function deleteEvent(user, eventId) {
  const auth = getClientForUser(user);
  const cal  = google.calendar({ version: 'v3', auth });
  await cal.events.delete({ calendarId: 'primary', eventId });
}

// ── GMAIL ─────────────────────────────────────────────────────────────────────
const PENDING_PATTERNS = [
  /me liga (?:em |daqui a )?(\d+) dias?/i,
  /ligo (?:em |daqui a )?(\d+) dias?/i,
  /falo (?:com você )?(?:em |daqui a )?(\d+) dias?/i,
  /retorno (?:em |daqui a )?(\d+) dias?/i,
  /entre em contato (?:em |daqui a )?(\d+) dias?/i,
  /call me in (\d+) days?/i,
  /follow.?up in (\d+) days?/i,
  /talk (?:to you )?in (\d+) days?/i,
];

async function getRecentEmails(user, maxResults = 20) {
  const auth  = getClientForUser(user);
  const gmail = google.gmail({ version: 'v1', auth });

  const list = await gmail.users.messages.list({
    userId: 'me',
    maxResults,
    labelIds: ['INBOX'],
    q: 'is:unread OR newer_than:3d',
  });
  if (!list.data.messages) return [];

  const emails = await Promise.all(
    list.data.messages.slice(0, maxResults).map(async (m) => {
      try {
        const msg = await gmail.users.messages.get({ userId: 'me', id: m.id, format: 'metadata', metadataHeaders: ['From', 'Subject', 'Date'] });
        const headers = msg.data.payload?.headers || [];
        const h = (name) => headers.find((h) => h.name === name)?.value || '';
        const snippet = msg.data.snippet || '';
        const pendingAction = detectPendingAction(snippet);
        return { id: m.id, from: h('From'), subject: h('Subject'), date: h('Date'), snippet, pendingAction };
      } catch { return null; }
    })
  );
  return emails.filter(Boolean);
}

function detectPendingAction(text) {
  for (const pattern of PENDING_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      const days = parseInt(match[1]);
      return { type: 'followup', days, dueDate: daysAhead(days), description: match[0] };
    }
  }
  return null;
}

module.exports = { listUpcomingEvents, createEvent, createReminder, deleteEvent, getRecentEmails, detectPendingAction, daysAhead, today };
