# CRM Leads — Agente de Follow-up

CRM completo com autenticação Google OAuth, Google Calendar e Gmail.

---

## 🚀 Deploy no Railway (recomendado — grátis)

### 1. Criar projeto Google Cloud

1. Acesse https://console.cloud.google.com
2. Crie um novo projeto (ex: `crm-leads`)
3. Menu lateral → **APIs & Services → Enable APIs**:
   - Ative **Google Calendar API**
   - Ative **Gmail API**
   - Ative **Google People API**
4. Menu lateral → **APIs & Services → OAuth consent screen**:
   - User type: **External**
   - App name: `CRM Leads`
   - Scopes: adicione `calendar`, `gmail.readonly`, `userinfo.email`, `userinfo.profile`
   - Test users: adicione `elsa.pilonieta@ecosysitech.com.br`
5. Menu lateral → **APIs & Services → Credentials**:
   - `+ Create Credentials → OAuth 2.0 Client ID`
   - Application type: **Web application**
   - Name: `CRM Leads Web`
   - **Authorized redirect URIs**: deixe em branco por enquanto (adiciona após o deploy)
   - Clique em **Create**
   - Copie o **Client ID** e **Client Secret**

### 2. Deploy no Railway

1. Acesse https://railway.app e faça login com GitHub
2. **New Project → Deploy from GitHub repo**
   - Conecte este repositório
3. Na aba **Variables**, adicione:
   ```
   GOOGLE_CLIENT_ID     = seu_client_id_aqui
   GOOGLE_CLIENT_SECRET = seu_client_secret_aqui
   SESSION_SECRET       = uma_string_aleatoria_longa_aqui
   NODE_ENV             = production
   ```
   - `BASE_URL` é definido automaticamente pelo Railway
4. Railway detecta o `package.json` e faz o deploy automaticamente
5. Copie a URL gerada (ex: `https://crm-leads.up.railway.app`)

### 3. Finalizar OAuth

1. Volte ao Google Cloud Console → **Credentials → seu OAuth Client**
2. Em **Authorized redirect URIs**, adicione:
   ```
   https://SEU-APP.up.railway.app/api/auth/google/callback
   ```
3. Salve

4. Se o app ainda estiver em modo de teste (OAuth consent screen), adicione o email como **Test user**

### 4. Testar

1. Acesse `https://SEU-APP.up.railway.app`
2. Clique em **Entrar com Google**
3. Authorize com a conta `elsa.pilonieta@ecosysitech.com.br`
4. Pronto! Google Agenda e Gmail integrados.

---

## 💻 Rodar localmente

```bash
# 1. Instalar dependências
npm install

# 2. Copiar e preencher variáveis
cp .env.example .env
# edite .env com suas credenciais Google

# 3. No Google Cloud, adicione à redirect URI:
#    http://localhost:3000/api/auth/google/callback

# 4. Iniciar
npm run dev
# Acesse http://localhost:3000
```

---

## 📁 Estrutura do projeto

```
crm-app/
├── server/
│   ├── index.js     — Express server
│   ├── routes.js    — API endpoints
│   ├── db.js        — SQLite (leads, atividades, usuários)
│   ├── auth.js      — Google OAuth helper
│   └── google.js    — Calendar + Gmail API
├── public/
│   ├── index.html   — SPA shell
│   ├── css/style.css
│   └── js/app.js    — Frontend completo
├── data/            — Criado automaticamente (banco SQLite)
├── .env.example
└── package.json
```

---

## ✅ Funcionalidades

- **Login** com Google OAuth 2.0
- **Dashboard** com KPIs, funil de conversão e atividades do dia
- **Leads** — CRUD completo, tag MTS, status, canal
- **Follow-up automático** — ciclo configurável (padrão: 2→7→14 dias)
- **Atividades** — criar, concluir, excluir, com lembrete automático na agenda
- **Google Agenda** — criar eventos com Google Meet, listar próximos eventos
- **Gmail Scan** — detecta ações pendentes ("me liga em X dias") e cria atividades
- **Configurações** — ajustar ciclo de follow-up, ver conta conectada
