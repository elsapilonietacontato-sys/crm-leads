/* ═══════════════════════════════════════════════════════════════════
   CRM LEADS — Frontend App
   Conecta à API /api/* (backend Node.js) que usa OAuth Google real
   ═══════════════════════════════════════════════════════════════════ */

// ── State ─────────────────────────────────────────────────────────────────────
const S = {
  user:       null,
  leads:      [],
  activities: [],
  calEvents:  [],
  currentSection: 'dashboard',
  editLeadId: null,
  fuDays: [2, 7, 14],
};

// ── Utils ─────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const today  = () => new Date().toISOString().slice(0, 10);
const fmtDate = s => {
  if (!s) return '—';
  const d = new Date(s + 'T00:00:00');
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
};
const fmtDateTime = s => {
  if (!s) return '—';
  const d = new Date(s);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) +
         ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
};
const initials = name => name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const AV_COLORS = ['av-teal','av-blue','av-amber','av-red','av-purple','av-gray'];
const avColor   = i => AV_COLORS[i % AV_COLORS.length];

let toastTimer;
function toast(msg, type = '') {
  const el = $('toast');
  el.textContent = msg;
  el.className = 'show' + (type ? ' ' + type : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = '', 3500);
}

// ── API helpers ───────────────────────────────────────────────────────────────
async function api(method, path, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api' + path, opts);
  if (res.status === 401) { showLogin(); throw new Error('Não autenticado'); }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro na API');
  return data;
}

// ── Auth ──────────────────────────────────────────────────────────────────────
async function init() {
  try {
    const user = await api('GET', '/auth/me');
    S.user = user;
    showApp();
    await loadAll();
  } catch {
    showLogin();
  }
}

function showLogin() {
  $('login-screen').style.display = 'flex';
  $('app').style.display = 'none';
}
function showApp() {
  $('login-screen').style.display = 'none';
  $('app').style.display = 'block';
  $('user-name').textContent = S.user.name || S.user.email;
  $('user-email').textContent = S.user.email;
  if (S.user.picture) $('user-pic').src = S.user.picture;
  else $('user-pic').style.display = 'none';
}
async function logout() {
  await api('POST', '/auth/logout');
  location.reload();
}

// ── Load all data ─────────────────────────────────────────────────────────────
async function loadAll() {
  const dash = await api('GET', '/dashboard');
  S.leads      = dash.leads;
  S.activities = dash.activities;
  updateKPIs(dash);
  renderSection(S.currentSection);
  updateNavBadges(dash);
}

function updateKPIs(d) {
  $('kpi-total').textContent = d.totalLeads;
  $('kpi-meet').textContent  = d.meetings;
  $('kpi-od').textContent    = d.overdue;
  $('kpi-act').textContent   = d.actOverdue;
}
function updateNavBadges(d) {
  const nb = $('nb-overdue');
  if (d.overdue > 0) { nb.textContent = d.overdue; nb.style.display = ''; }
  else nb.style.display = 'none';

  $('nb-leads').textContent = d.totalLeads;

  const fu = $('nb-fu');
  const fuCount = d.overdue + d.todayFU;
  if (fuCount > 0) { fu.textContent = fuCount; fu.style.display = ''; }
  else fu.style.display = 'none';
}

// ── Navigation ────────────────────────────────────────────────────────────────
const PAGE_TITLES = {
  dashboard:  'Painel de Leads',
  leads:      'Leads & Prospects',
  followup:   'Agenda de Follow-up',
  activities: 'Atividades & Pendências',
  agenda:     'Google Agenda',
  gmail:      'Escanear Gmail',
  config:     'Configurações',
};

function navTo(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  $(`sec-${id}`).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => {
    if (n.dataset.section === id) n.classList.add('active');
  });
  $('page-title').textContent = PAGE_TITLES[id] || id;
  S.currentSection = id;
  renderSection(id);
}

document.querySelectorAll('.nav-item').forEach(n => {
  n.addEventListener('click', () => navTo(n.dataset.section));
});

function renderSection(id) {
  if (id === 'dashboard')  renderDashboard();
  if (id === 'leads')      renderLeads();
  if (id === 'followup')   renderFollowup();
  if (id === 'activities') renderActivities();
  if (id === 'config')     renderConfig();
}

// ── Status helpers ────────────────────────────────────────────────────────────
const STATUS_LABEL = { novo:'Novo', abordado:'Abordado', 'follow-up':'Follow-up', agendado:'Agendado', descartado:'Descartado' };
const STATUS_DOT   = { novo:'dot-blue', abordado:'dot-purple', 'follow-up':'dot-amber', agendado:'dot-green', descartado:'dot-gray' };
const STATUS_BADGE = { novo:'badge-blue', abordado:'badge-purple', 'follow-up':'badge-amber', agendado:'badge-green', descartado:'badge-gray' };

function statusBadge(l) {
  const tod = today();
  if (l.status === 'agendado')    return '<span class="badge badge-green">Agendado ✓</span>';
  if (l.status === 'descartado')  return '<span class="badge badge-gray">Descartado</span>';
  if (l.status === 'novo')        return '<span class="badge badge-blue">Novo</span>';
  if (l.next_fu && l.next_fu < tod) return '<span class="badge badge-red">Vencido</span>';
  if (l.next_fu && l.next_fu === tod) return '<span class="badge badge-amber">Hoje</span>';
  return `<span class="badge badge-gray">${fmtDate(l.next_fu)}</span>`;
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
function renderDashboard() {
  const tod    = today();
  const active = S.leads.filter(l => l.status !== 'descartado');
  const mts    = active.filter(l => l.tag === 'MTS');
  const overdue = active.filter(l => l.next_fu && l.next_fu < tod && l.status !== 'agendado');

  // Notify bar
  const notifEl = $('dash-notify');
  if (overdue.length > 0) {
    notifEl.innerHTML = `<div class="notify warn">
      <span>⚠️ <strong>${overdue.length} follow-up${overdue.length>1?'s':''} vencido${overdue.length>1?'s':''}</strong> — ${overdue.map(l=>l.name).join(', ')}. Clique em <a href="#" onclick="navTo('followup');return false;" style="color:var(--amber-dark);font-weight:600;">Follow-up</a> para agir agora.</span>
      <span class="notify-close" onclick="this.closest('.notify').remove()">×</span>
    </div>`;
  } else {
    notifEl.innerHTML = '';
  }

  // Lead list
  const dl = $('dash-leads');
  if (!mts.length) {
    dl.innerHTML = `<div class="cal-empty">Nenhum lead MTS ativo.<br>Clique em <strong>+ Lead</strong> para começar.</div>`;
  } else {
    dl.innerHTML = mts.map((l, i) => `
      <div class="lead-row">
        <div class="av av-sm ${avColor(i)}">${initials(l.name)}</div>
        <div class="lead-info">
          <div class="lead-name">${l.name}${l.company ? ` <span class="text-muted small">· ${l.company}</span>` : ''}</div>
          <div class="lead-sub">${l.channel} · ${STATUS_LABEL[l.status]}</div>
        </div>
        ${statusBadge(l)}
      </div>`).join('');
  }

  // Funil
  const total    = active.length || 1;
  const approach = active.filter(l => l.status !== 'novo').length;
  const respond  = active.filter(l => ['agendado','follow-up'].includes(l.status)).length;
  const meets    = active.filter(l => l.status === 'agendado').length;
  $('funnel-wrap').innerHTML = `
    <div class="funnel-bar-row">
      <div class="funnel-seg" style="flex:${total};background:#B5D4F4;color:#042C53;">${total} Leads</div>
      <div class="funnel-seg" style="flex:${Math.max(approach,1)};background:#85B7EB;color:#042C53;">${approach}</div>
      <div class="funnel-seg" style="flex:${Math.max(respond,1)};background:#378ADD;color:#fff;">${respond}</div>
      <div class="funnel-seg" style="flex:${Math.max(meets,1)};background:#185FA5;color:#fff;">${meets} ✓</div>
    </div>
    <div class="funnel-legend">
      <div class="funnel-legend-item"><div class="funnel-legend-dot" style="background:#B5D4F4"></div>Leads</div>
      <div class="funnel-legend-item"><div class="funnel-legend-dot" style="background:#85B7EB"></div>Abordados</div>
      <div class="funnel-legend-item"><div class="funnel-legend-dot" style="background:#378ADD"></div>Responderam</div>
      <div class="funnel-legend-item"><div class="funnel-legend-dot" style="background:#185FA5"></div>Reuniões</div>
    </div>`;

  // Atividades pendentes
  const pending = S.activities.filter(a => !a.done).slice(0, 5);
  const daEl = $('dash-acts');
  if (!pending.length) {
    daEl.innerHTML = `<div class="text-muted small" style="padding:12px 0">Nenhuma atividade pendente 🎉</div>`;
  } else {
    const icons = { Reunião:'📋', WhatsApp:'💬', Email:'📧', Ligação:'📞', Videoconferência:'🎥', Manual:'✏️' };
    daEl.innerHTML = `<div class="timeline">${pending.map(a => {
      const overd = a.due_date < tod;
      return `<div class="tl-item">
        <div class="tl-icon" style="background:${overd ? 'var(--red-light)' : 'var(--surface3)'}">${icons[a.origin] || '📋'}</div>
        <div class="tl-body">
          <div class="tl-label" style="color:${overd ? 'var(--red)' : 'var(--text)'}">${a.description}</div>
          <div class="tl-time">${a.contact ? a.contact + ' · ' : ''}${fmtDate(a.due_date)}${overd ? ' · <span style="color:var(--red)">vencido</span>' : ''}</div>
        </div>
      </div>`;
    }).join('')}</div>`;
  }
}

// ── LEADS ─────────────────────────────────────────────────────────────────────
function renderLeads() {
  const tb = $('leads-body');
  if (!S.leads.length) {
    tb.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text3)">Nenhum lead cadastrado. Clique em <strong>+ Lead</strong>.</td></tr>`;
    return;
  }
  tb.innerHTML = S.leads.map((l, i) => `
    <tr id="lead-row-${l.id}">
      <td>
        <div class="flex items-center gap-8">
          <div class="av av-sm ${avColor(i)}">${initials(l.name)}</div>
          <div>
            <div class="fw-500">${l.name}</div>
            ${l.company ? `<div class="small text-muted">${l.company}</div>` : ''}
          </div>
        </div>
      </td>
      <td>${l.channel}</td>
      <td><span class="dot ${STATUS_DOT[l.status]}"></span>${STATUS_LABEL[l.status]}</td>
      <td>${l.tag === 'MTS' ? '<span class="badge badge-mts">MTS</span>' : `<span class="badge badge-gray">${l.tag}</span>`}</td>
      <td style="color:${l.next_fu && l.next_fu < today() && l.status !== 'agendado' ? 'var(--red)' : 'var(--text)'}">
        ${l.status === 'agendado' ? '✓ Agendado' : (l.next_fu ? fmtDate(l.next_fu) : '—')}
      </td>
      <td>
        <div class="row-actions">
          <button class="btn btn-icon" title="Editar" onclick="openEditLead(${l.id})">✏️</button>
          <button class="btn btn-icon" title="${l.tag === 'MTS' ? 'Remover MTS' : 'Marcar como MTS'}" onclick="toggleMTS(${l.id})" style="${l.tag==='MTS'?'background:var(--green-light)':''}">🏷️</button>
          <button class="btn btn-icon" title="Agendar reunião" onclick="openSchedule(${l.id})">📅</button>
          <button class="btn btn-icon btn-danger" title="Descartar" onclick="discardLead(${l.id})">🗑️</button>
        </div>
      </td>
    </tr>`).join('');
}

async function saveLead() {
  const name = $('l-name').value.trim();
  if (!name) { toast('Nome do lead é obrigatório.', 'error'); return; }
  try {
    const lead = await api('POST', '/leads', {
      name, company: $('l-company').value,
      channel: $('l-channel').value, contact: $('l-contact').value,
      tag: $('l-tag').value, status: $('l-status').value,
      notes: $('l-notes').value,
    });
    S.leads.unshift(lead);
    closeModal('modal-lead');
    ['l-name','l-company','l-contact','l-notes'].forEach(id => $(id).value = '');
    renderSection(S.currentSection);
    toast(`Lead "${name}" adicionado! Primeiro follow-up em ${S.fuDays[0]} dias.`, 'success');
  } catch (e) { toast(e.message, 'error'); }
}

function openEditLead(id) {
  const l = S.leads.find(x => x.id === id);
  if (!l) return;
  S.editLeadId = id;
  $('el-id').value = id;
  $('el-name').value    = l.name;
  $('el-company').value = l.company || '';
  $('el-channel').value = l.channel;
  $('el-contact').value = l.contact || '';
  $('el-tag').value     = l.tag;
  $('el-status').value  = l.status;
  $('el-notes').value   = l.notes || '';
  openModal('modal-edit-lead');
}

async function updateLead() {
  const id = S.editLeadId;
  try {
    const updated = await api('PUT', `/leads/${id}`, {
      name:    $('el-name').value,
      company: $('el-company').value,
      channel: $('el-channel').value,
      contact: $('el-contact').value,
      tag:     $('el-tag').value,
      status:  $('el-status').value,
      notes:   $('el-notes').value,
    });
    const idx = S.leads.findIndex(l => l.id === id);
    if (idx !== -1) S.leads[idx] = updated;
    closeModal('modal-edit-lead');
    renderSection(S.currentSection);
    updateNavBadges({ totalLeads: S.leads.filter(l=>l.status!=='descartado').length, overdue: countOverdue(), todayFU: countTodayFU(), meetings: countMeetings(), actOverdue: countActOverdue() });
    toast('Lead atualizado.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

async function deleteLead() {
  if (!confirm('Excluir este lead permanentemente?')) return;
  try {
    await api('DELETE', `/leads/${S.editLeadId}`);
    S.leads = S.leads.filter(l => l.id !== S.editLeadId);
    closeModal('modal-edit-lead');
    renderSection(S.currentSection);
    toast('Lead excluído.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

async function discardLead(id) {
  if (!confirm('Marcar este lead como descartado?')) return;
  try {
    const updated = await api('PUT', `/leads/${id}`, {
      ...S.leads.find(l => l.id === id), status: 'descartado', next_fu: null,
    });
    const idx = S.leads.findIndex(l => l.id === id);
    if (idx !== -1) S.leads[idx] = updated;
    renderSection(S.currentSection);
    toast('Lead descartado.');
  } catch (e) { toast(e.message, 'error'); }
}

async function toggleMTS(id) {
  const l = S.leads.find(x => x.id === id);
  if (!l) return;
  const newTag = l.tag === 'MTS' ? 'Outro' : 'MTS';
  try {
    const updated = await api('PUT', `/leads/${id}`, { ...l, tag: newTag });
    const idx = S.leads.findIndex(x => x.id === id);
    if (idx !== -1) S.leads[idx] = updated;
    renderSection(S.currentSection);
    toast(`Tag alterada para "${newTag}".`);
  } catch (e) { toast(e.message, 'error'); }
}

// ── FOLLOW-UP ─────────────────────────────────────────────────────────────────
function renderFollowup() {
  const tod = today();
  const active  = S.leads.filter(l => l.status !== 'descartado' && l.status !== 'agendado');
  const overdue = active.filter(l => l.next_fu && l.next_fu < tod);
  const todayFU = active.filter(l => l.next_fu === tod);
  const upcoming= active.filter(l => l.next_fu && l.next_fu > tod);

  const el = $('fu-content');
  let html = '';

  const laneHTML = (items, cls, laneClass, label, color, countBg) => {
    if (!items.length) return '';
    return `
      <div class="lane">
        <div class="lane-hd" style="color:${color}">
          ${label}
          <span class="lane-count" style="background:${countBg};color:${color}">${items.length}</span>
        </div>
        <div class="lane-body ${laneClass}">
          ${items.map(l => `
            <div class="lane-item ${cls}">
              <div class="lane-item-info">
                <div class="lane-name">${l.name}${l.company ? ` <span class="text-muted small">· ${l.company}</span>` : ''}</div>
                <div class="lane-sub">${l.channel} · ${l.fu_count + 1}º follow-up · ${fmtDate(l.next_fu)}</div>
              </div>
              <div class="row-actions">
                <button class="btn btn-sm" onclick="openSchedule(${l.id})" title="Agendar reunião">📅 Agendar</button>
                <button class="btn btn-sm btn-ghost" onclick="fuDone(${l.id})" title="Marcar feito e avançar">✓ Feito</button>
              </div>
            </div>`).join('')}
        </div>
      </div>`;
  };

  html += laneHTML(overdue, 'overdue', 'red-lane', 'Vencidos', 'var(--red)', 'var(--red-light)');
  html += laneHTML(todayFU, 'today-fu', 'amber-lane', 'Hoje', 'var(--amber)', 'var(--amber-light)');
  html += laneHTML(upcoming, 'upcoming', 'green-lane', 'Próximos', 'var(--green)', 'var(--green-light)');

  if (!html) {
    html = `<div class="cal-empty">🎉 Nenhum follow-up pendente.<br><span class="text-muted small">Todos os leads estão em dia!</span></div>`;
  }
  el.innerHTML = html;
}

async function fuDone(id) {
  try {
    const updated = await api('POST', `/leads/${id}/followup-done`);
    const idx = S.leads.findIndex(l => l.id === id);
    if (idx !== -1) S.leads[idx] = updated;
    if (updated.fu_count >= 3) toast('Todos os follow-ups realizados. Lead marcado como frio.');
    else toast(`Follow-up concluído! Próximo em ${S.fuDays[updated.fu_count]} dias.`, 'success');
    renderSection(S.currentSection);
    updateNavBadges({ totalLeads: S.leads.filter(l=>l.status!=='descartado').length, overdue: countOverdue(), todayFU: countTodayFU(), meetings: countMeetings(), actOverdue: countActOverdue() });
  } catch (e) { toast(e.message, 'error'); }
}

// ── ACTIVITIES ────────────────────────────────────────────────────────────────
function renderActivities() {
  const tb = $('act-body');
  if (!S.activities.length) {
    tb.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text3)">Nenhuma atividade. Clique em <strong>+ Atividade</strong>.</td></tr>`;
    return;
  }
  const tod = today();
  const origins = { Reunião:'📋', WhatsApp:'💬', Email:'📧', Ligação:'📞', Videoconferência:'🎥', Manual:'✏️', 'Email/IA':'🤖' };
  tb.innerHTML = S.activities.map(a => {
    const overdue = !a.done && a.due_date < tod;
    const dueColor = overdue ? 'var(--red)' : a.due_date === tod ? 'var(--amber)' : 'var(--text)';
    return `
      <tr id="act-row-${a.id}" class="${a.done ? 'done' : ''}">
        <td>${a.description}</td>
        <td>${a.contact || '—'}</td>
        <td><span class="badge badge-gray">${origins[a.origin] || ''}  ${a.origin}</span></td>
        <td style="color:${dueColor}">${fmtDate(a.due_date)}</td>
        <td>
          ${a.done
            ? '<span class="dot dot-green"></span>Concluído'
            : `<span class="dot ${overdue ? 'dot-red' : a.due_date === tod ? 'dot-amber' : 'dot-blue'}"></span>${overdue ? 'Vencido' : a.due_date === tod ? 'Hoje' : 'Pendente'}`}
        </td>
        <td>
          <div class="row-actions">
            <button class="btn btn-icon" title="${a.done ? 'Reabrir' : 'Concluir'}" onclick="toggleActivity(${a.id},${a.done ? 0 : 1})">${a.done ? '↩️' : '✓'}</button>
            <button class="btn btn-icon btn-danger" title="Excluir" onclick="deleteActivity(${a.id})">🗑️</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

async function saveActivity() {
  const desc = $('a-desc').value.trim();
  if (!desc) { toast('Descrição é obrigatória.', 'error'); return; }
  try {
    const act = await api('POST', '/activities', {
      description:    desc,
      contact:        $('a-contact').value,
      origin:         $('a-origin').value,
      due_date:       $('a-due').value || today(),
      create_reminder: $('a-reminder').checked,
    });
    S.activities.unshift(act);
    closeModal('modal-activity');
    ['a-desc','a-contact','a-due'].forEach(id => $(id).value = '');
    $('a-reminder').checked = true;
    renderSection(S.currentSection);
    toast(act.gcal_event_id ? 'Atividade criada e lembrete adicionado na agenda! 📅' : 'Atividade criada.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

async function toggleActivity(id, done) {
  try {
    await api('PATCH', `/activities/${id}/done`, { done });
    const a = S.activities.find(x => x.id === id);
    if (a) a.done = done;
    renderActivities();
    toast(done ? 'Atividade concluída! ✓' : 'Atividade reaberta.');
    updateNavBadges({ totalLeads: S.leads.filter(l=>l.status!=='descartado').length, overdue: countOverdue(), todayFU: countTodayFU(), meetings: countMeetings(), actOverdue: countActOverdue() });
  } catch (e) { toast(e.message, 'error'); }
}

async function deleteActivity(id) {
  if (!confirm('Excluir esta atividade?')) return;
  try {
    await api('DELETE', `/activities/${id}`);
    S.activities = S.activities.filter(a => a.id !== id);
    renderActivities();
    toast('Atividade excluída.');
  } catch (e) { toast(e.message, 'error'); }
}

// ── AGENDA ────────────────────────────────────────────────────────────────────
function openSchedule(leadId) {
  navTo('agenda');
  const l = S.leads.find(x => x.id === leadId);
  if (!l) return;
  $('ev-title').value = `Reunião de prospecção — ${l.name}`;
  if (l.contact && l.contact.includes('@')) $('ev-email').value = l.contact;
  $('ev-desc').value  = `Lead MTS${l.company ? ' · ' + l.company : ''}.\n\n${l.notes || ''}`.trim();
  $('ev-meet').checked = true;
  $('ev-lead').value  = leadId;
  toast(`Preencha data e hora para agendar com ${l.name}`);
}

async function createCalEvent() {
  const title = $('ev-title').value.trim();
  const start = $('ev-start').value;
  const end   = $('ev-end').value;
  if (!title || !start || !end) { toast('Preencha título, início e fim.', 'error'); return; }

  const btn = document.querySelector('#sec-agenda .btn-primary');
  btn.disabled = true;
  btn.textContent = 'Agendando…';

  try {
    const ev = await api('POST', '/calendar/events', {
      summary:       title,
      description:   $('ev-desc').value,
      startDateTime: new Date(start).toISOString(),
      endDateTime:   new Date(end).toISOString(),
      attendeeEmail: $('ev-email').value || null,
      addMeet:       $('ev-meet').checked,
      leadId:        $('ev-lead').value || null,
    });

    const resultEl = $('ev-result');
    resultEl.className = 'result-msg';
    resultEl.style.display = 'block';

    let msg = `✅ Evento criado! <strong>${title}</strong><br>${fmtDateTime(start)}`;
    if (ev.hangoutLink) msg += `<br>Google Meet: <a href="${ev.hangoutLink}" target="_blank" class="cal-event-link">Entrar na reunião</a>`;
    if (ev.htmlLink) msg += ` · <a href="${ev.htmlLink}" target="_blank" class="cal-event-link">Ver na Agenda</a>`;
    resultEl.innerHTML = msg;

    // Se tem lead relacionado, atualiza status local
    const leadId = parseInt($('ev-lead').value);
    if (leadId) {
      const idx = S.leads.findIndex(l => l.id === leadId);
      if (idx !== -1) { S.leads[idx].status = 'agendado'; S.leads[idx].next_fu = null; }
    }
    toast('Reunião agendada no Google Calendar! 📅', 'success');
    renderDashboard();
  } catch (e) {
    const r = $('ev-result');
    r.className = 'result-msg error';
    r.style.display = 'block';
    r.textContent = '❌ Erro: ' + e.message;
  }
  btn.disabled = false;
  btn.textContent = '📅 Agendar na Google Agenda';
}

async function loadCalendar() {
  const el = $('cal-list');
  el.innerHTML = '<div class="text-muted small">Carregando eventos…</div>';
  try {
    const events = await api('GET', '/calendar/events');
    if (!events.length) {
      el.innerHTML = '<div class="cal-empty">Nenhum evento nos próximos 30 dias.</div>';
      return;
    }
    el.innerHTML = events.map(ev => {
      const st   = ev.start?.dateTime || ev.start?.date;
      const dt   = st ? new Date(st) : null;
      const date = dt ? dt.toLocaleDateString('pt-BR', { day:'2-digit', month:'short' }) : '—';
      const hour = dt && ev.start?.dateTime ? dt.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' }) : 'Dia todo';
      const attendees = (ev.attendees || []).map(a => a.email).filter(Boolean).join(', ');
      const meet = ev.hangoutLink;
      return `
        <div class="cal-event">
          <div class="cal-event-time"><div class="cal-event-date">${date}</div><div class="cal-event-hour">${hour}</div></div>
          <div class="cal-event-dot"></div>
          <div class="cal-event-info">
            <div class="cal-event-title">${ev.summary || '(sem título)'}</div>
            ${attendees ? `<div class="cal-event-sub">👥 ${attendees}</div>` : ''}
            ${meet ? `<a href="${meet}" target="_blank" class="cal-event-link">🎥 Entrar no Meet</a>` : ''}
          </div>
        </div>`;
    }).join('');
  } catch (e) {
    el.innerHTML = `<div class="result-msg error">Erro ao carregar agenda: ${e.message}</div>`;
  }
}

// Popula o select de leads na aba Agenda
function populateLeadSelect() {
  const sel = $('ev-lead');
  if (!sel) return;
  const active = S.leads.filter(l => l.status !== 'descartado');
  sel.innerHTML = '<option value="">— Nenhum —</option>' +
    active.map(l => `<option value="${l.id}">${l.name}${l.company ? ' · ' + l.company : ''}</option>`).join('');
}

// ── GMAIL SCAN ────────────────────────────────────────────────────────────────
async function scanGmail() {
  const el = $('gmail-result');
  el.innerHTML = '<div class="text-muted small">Escaneando emails… aguarde.</div>';
  try {
    const result = await api('GET', '/gmail/scan');
    if (!result.all.length) {
      el.innerHTML = '<div class="cal-empty">Nenhum email recente encontrado.</div>';
      return;
    }

    const pendCount = result.withActions.length;
    let html = `<div class="notify ${pendCount > 0 ? 'warn' : ''}" style="margin-bottom:14px">
      ${pendCount > 0
        ? `⚠️ <strong>${pendCount} email${pendCount>1?'s':''} com ação pendente detectada</strong> em ${result.total} emails escaneados.`
        : `✅ Nenhuma ação pendente detectada em ${result.total} emails recentes.`}
    </div>`;

    html += result.all.map(e => {
      const pa = e.pendingAction;
      return `<div class="gmail-item">
        <div class="gmail-from">${e.from}</div>
        <div class="gmail-subject">${e.subject || '(sem assunto)'}</div>
        <div class="gmail-snippet">${e.snippet}</div>
        ${pa ? `<div class="gmail-action">
          <span class="gmail-pending">⏰ Ação detectada: "${pa.description}" — vencimento ${fmtDate(pa.dueDate)}</span>
          <button class="btn btn-sm btn-primary" onclick="createActivityFromEmail('${e.from.replace(/'/g,"\\'")}','${pa.description.replace(/'/g,"\\'")}','${pa.dueDate}')">
            + Criar atividade
          </button>
        </div>` : ''}
      </div>`;
    }).join('');

    el.innerHTML = html;
  } catch (e) {
    el.innerHTML = `<div class="result-msg error">Erro ao escanear Gmail: ${e.message}</div>`;
  }
}

async function createActivityFromEmail(from, desc, dueDate) {
  try {
    const act = await api('POST', '/activities', {
      description:     desc,
      contact:         from,
      origin:          'Email',
      due_date:        dueDate,
      create_reminder: true,
    });
    S.activities.unshift(act);
    toast('Atividade criada e lembrete adicionado na agenda! 📅', 'success');
    scanGmail();
  } catch (e) { toast(e.message, 'error'); }
}

// ── CONFIG ────────────────────────────────────────────────────────────────────
function renderConfig() {
  const el = $('sec-config');
  if (!el) return;
  el.innerHTML = `
    <div class="card">
      <div class="card-hd"><h3>Integrações</h3></div>
      <div class="config-row">
        <div><div class="config-label">Google Agenda</div><div class="config-sub">Agendar reuniões e criar lembretes automaticamente</div></div>
        <div class="flex items-center gap-8"><span class="badge badge-green">✓ Conectado</span><div class="conn-indicator"><div class="conn-dot on"></div>${S.user?.email || ''}</div></div>
      </div>
      <div class="config-row">
        <div><div class="config-label">Gmail</div><div class="config-sub">Detectar ações pendentes em emails recebidos</div></div>
        <div class="flex items-center gap-8"><span class="badge badge-green">✓ Conectado</span></div>
      </div>
      <div class="config-row">
        <div><div class="config-label">WhatsApp Business</div><div class="config-sub">Identificar leads MTS em conversas de negócios (em breve)</div></div>
        <div class="flex items-center gap-8"><span class="badge badge-gray">Em breve</span></div>
      </div>
    </div>

    <div class="card">
      <div class="card-hd"><h3>Ciclo de follow-up automático</h3></div>
      <div class="config-row">
        <div><div class="config-label">1º follow-up (sem resposta)</div><div class="config-sub">Dias após o primeiro contato</div></div>
        <div class="config-days"><input type="number" id="cfg-d1" value="${S.fuDays[0]}" min="1" max="30"><span class="text-muted small">dias</span></div>
      </div>
      <div class="config-row">
        <div><div class="config-label">2º follow-up</div><div class="config-sub">Dias após o 1º follow-up sem resposta</div></div>
        <div class="config-days"><input type="number" id="cfg-d2" value="${S.fuDays[1]}" min="1" max="30"><span class="text-muted small">dias</span></div>
      </div>
      <div class="config-row">
        <div><div class="config-label">3º follow-up (último toque)</div><div class="config-sub">Antes de marcar como frio</div></div>
        <div class="config-days"><input type="number" id="cfg-d3" value="${S.fuDays[2]}" min="1" max="60"><span class="text-muted small">dias</span></div>
      </div>
      <div style="margin-top:16px">
        <button class="btn btn-primary" onclick="saveConfig()">Salvar configurações</button>
      </div>
    </div>

    <div class="card">
      <div class="card-hd"><h3>Conta</h3></div>
      <div class="config-row">
        <div><div class="config-label">${S.user?.name || ''}</div><div class="config-sub">${S.user?.email || ''}</div></div>
        <button class="btn btn-danger btn-sm" onclick="logout()">Sair da conta</button>
      </div>
    </div>`;
}

function saveConfig() {
  const d1 = parseInt($('cfg-d1')?.value || 2);
  const d2 = parseInt($('cfg-d2')?.value || 7);
  const d3 = parseInt($('cfg-d3')?.value || 14);
  S.fuDays = [d1, d2, d3];
  localStorage.setItem('crm_fuDays', JSON.stringify(S.fuDays));
  toast('Configurações salvas!', 'success');
}

// ── Modals ────────────────────────────────────────────────────────────────────
function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

document.querySelectorAll('.overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target === el) el.classList.remove('open'); });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') document.querySelectorAll('.overlay.open').forEach(el => el.classList.remove('open'));
});

// ── Counters ──────────────────────────────────────────────────────────────────
function countOverdue()    { const t=today(); return S.leads.filter(l=>l.next_fu&&l.next_fu<t&&l.status!=='agendado'&&l.status!=='descartado').length; }
function countTodayFU()    { const t=today(); return S.leads.filter(l=>l.next_fu===t&&l.status!=='agendado'&&l.status!=='descartado').length; }
function countMeetings()   { return S.leads.filter(l=>l.status==='agendado').length; }
function countActOverdue() { const t=today(); return S.activities.filter(a=>!a.done&&a.due_date<t).length; }

// ── Set default dates ─────────────────────────────────────────────────────────
function setDefaultDates() {
  const now   = new Date();
  const plus1 = new Date(now.getTime() + 3600000);
  const toISO = d => d.toISOString().slice(0, 16);
  if ($('ev-start') && !$('ev-start').value) $('ev-start').value = toISO(now);
  if ($('ev-end')   && !$('ev-end').value)   $('ev-end').value   = toISO(plus1);
  if ($('a-due')    && !$('a-due').value)    $('a-due').value    = today();
}

// Populate lead select when opening agenda tab
document.querySelectorAll('.nav-item').forEach(n => {
  if (n.dataset.section === 'agenda') {
    n.addEventListener('click', () => {
      populateLeadSelect();
      setDefaultDates();
      loadCalendar();
    });
  }
});

// ── Restore saved config ──────────────────────────────────────────────────────
try {
  const saved = localStorage.getItem('crm_fuDays');
  if (saved) S.fuDays = JSON.parse(saved);
} catch {}

// ── Start ─────────────────────────────────────────────────────────────────────
init();
